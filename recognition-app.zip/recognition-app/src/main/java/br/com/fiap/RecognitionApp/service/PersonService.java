package br.com.fiap.RecognitionApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.fiap.RecognitionApp.dto.PersonDto;
import br.com.fiap.RecognitionApp.model.Person;
import br.com.fiap.RecognitionApp.repository.PersonRepository;

@Service
public class PersonService {
	
	@Autowired
	private PersonRepository repository;
	
	public List<PersonDto> getPerson(){
		
		return PersonDto.converter(repository.findAll());
	}
	
	public List<PersonDto> getPersonById(long id){
		
		return PersonDto.converterID(repository.findById(id));
	}
	
	 public ResponseEntity<Person> save (Person person){
	    	repository.save(person);
	    	return ResponseEntity.ok(person);
	    }
	 
	  public ResponseEntity<Person> update(Person person){
			Person personToEdit = repository.getOne(person.getId());
			
			if(personToEdit==null) new ResponseEntity<>(HttpStatus.BAD_REQUEST); 
			personToEdit = person;
			
			repository.save(personToEdit);
			return new ResponseEntity<>(HttpStatus.OK); 

	    }
	    public ResponseEntity<?> delete( long id){
			return repository.findById(id).map(mapper -> {
					repository.deleteById(id);
					return ResponseEntity.ok().build();
	        }).orElse(ResponseEntity.notFound().build());
		}
	 
}
