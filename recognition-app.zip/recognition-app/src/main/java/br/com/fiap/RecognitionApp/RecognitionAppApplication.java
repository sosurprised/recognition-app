package br.com.fiap.RecognitionApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecognitionAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecognitionAppApplication.class, args);
	}
	

}
