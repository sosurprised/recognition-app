package br.com.fiap.RecognitionApp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.fiap.RecognitionApp.dto.UserDto;
import br.com.fiap.RecognitionApp.model.User;
import br.com.fiap.RecognitionApp.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService service;
	
	@GetMapping()
	public List<UserDto> getAll() {
		return service.getUser();
	}
	@GetMapping("/{id}")
	public List<UserDto> getByid(@PathVariable(value = "id") long id){
		return service.getByIdUser(id);
	}
	
	@PostMapping()
	public ResponseEntity<User> save(@Valid @RequestBody User user, BindingResult result) {
		//if (result.hasErrors()) return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		service.save(user);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<User> updateUser(@Valid @RequestBody User user, BindingResult result, RedirectAttributes redirect) {
		if (result.hasErrors()) return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	
		return service.updateUser(user);
	}
	
	@GetMapping("/delete/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable Long id, RedirectAttributes redirect) {
	
		service.delete(id);
		return new ResponseEntity<>(HttpStatus.OK); 
	}	
}
	