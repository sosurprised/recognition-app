package br.com.fiap.RecognitionApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.RecognitionApp.model.FaceRectangle;

public interface FaceRectangleRepository extends JpaRepository<FaceRectangle, Long>{

}
