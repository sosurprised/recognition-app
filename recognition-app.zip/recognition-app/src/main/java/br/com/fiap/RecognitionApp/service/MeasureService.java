package br.com.fiap.RecognitionApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.fiap.RecognitionApp.model.Measure;
import br.com.fiap.RecognitionApp.repository.MeasureRepository;

@Service
public class MeasureService {

	@Autowired
	private MeasureRepository repository;
	
	public List<Measure> getUser(){
    	
    	return repository.findAll();
    }
	public ResponseEntity<Measure> save (Measure measure){
    	repository.save(measure);
    	return ResponseEntity.ok(measure);
    }
    public ResponseEntity<Measure> updateUser(Measure measure){
		Measure measureToEdit = repository.getOne(measure.getId());
		
		if(measureToEdit==null) new ResponseEntity<>(HttpStatus.BAD_REQUEST); 
		measureToEdit = measure;
		
		repository.save(measureToEdit);
		return new ResponseEntity<>(HttpStatus.OK); 

    }
    public ResponseEntity<?> delete( long id){
		return repository.findById(id).map(mapper -> {
				repository.deleteById(id);
				return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
	}
	
    
}
