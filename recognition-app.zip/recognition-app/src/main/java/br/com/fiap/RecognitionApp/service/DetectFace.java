package br.com.fiap.RecognitionApp.service;

import java.net.URI;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;



public class DetectFace {
	{
		String subscription_Key = "8b5d12ba2bcb464c997ff4f8e3f600f3";
		String endpoint = "https://ps.cognitiveservices.azure.com/";
		

	     String imageWithFaces =
	        "{\"url\":\"https://upload.wikimedia.org/wikipedia/commons/c/c3/RH_Louise_Lillian_Gish.jpg\"}";
    try
    {
    	HttpClient httpclient = HttpClientBuilder.create().build();

        URIBuilder builder = new URIBuilder(endpoint + "/face/v1.0/detect");

        // Request parameters. All of them are optional.
        builder.setParameter("detectionModel", "detection_02");
        builder.setParameter("returnFaceId", "true");

        // Prepare the URI for the REST API call.
        URI uri = builder.build();
        HttpPost request = new HttpPost(uri);

        // Request headers.
        request.setHeader("Content-Type", "application/json");
        request.setHeader("Ocp-Apim-Subscription-Key", subscription_Key);

        // Request body.
        StringEntity reqEntity = new StringEntity(imageWithFaces);
        request.setEntity(reqEntity);

        // Execute the REST API call and get the response entity.
        HttpResponse response = httpclient.execute(request);
        HttpEntity entity = response.getEntity();
        Gson gson = new Gson();
     
       if (entity != null)
        {
            // Format and display the JSON response.
            System.out.println("REST Response:\n");
            String jsonString = EntityUtils.toString(entity).trim();

            if (jsonString.charAt(0) == '[') {
                JSONArray jsonArray = new JSONArray(jsonString);
                System.out.println("xD" + jsonArray.toString(2));
                
                for(int i = 0; i < jsonArray.length(); i++){
                    JSONObject o = jsonArray.getJSONObject(i);
                    System.out.println(o.get("faceId"));
                    System.out.println(o.get("faceRectangle"));
                   System.out.println(o.getString("faceRectangle:{top}"));
                   
                }
               
            }
            else if (jsonString.charAt(0) == '{') {
                JSONObject jsonObject = new JSONObject(jsonString);
                System.out.println(jsonObject.toString(2));
            } else {
                System.out.println(jsonString);
            }
        }
    }
    catch (Exception e)
    {
        // Display error message.
        System.out.println(e.getMessage());
    }
}
}

