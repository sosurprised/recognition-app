package br.com.fiap.RecognitionApp.dto;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import br.com.fiap.RecognitionApp.model.FaceRectangle;

public class FaceRectangleDto {
	public FaceRectangleDto() {
		
	}
	public FaceRectangleDto(FaceRectangle face) {
		this.id = face.getId();
		this.top = face.getTop();
		this.left = face.getLeft();
		this.width = face.getWidth();
		this.height = face.getHeight();
		this.faceId = face.getMeasureId().getId();
	}
	private Long id;
	private int top;
	private int left;
	private int width;
	private int height;
	@NotNull
	private Long faceId;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getTop() {
		return top;
	}
	public void setTop(int top) {
		this.top = top;
	}
	public int getLeft() {
		return left;
	}
	public void setLeft(int left) {
		this.left = left;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public Long getFaceId() {
		return faceId;
	}
	public void setFaceId(Long faceId) {
		this.faceId = faceId;
	}
	
	public static List<FaceRectangleDto> converter(List<FaceRectangle> face){
		return face.stream().map(FaceRectangleDto::new).collect(Collectors.toList());
	}
	
	
	public static List<FaceRectangleDto> converterID(Optional<FaceRectangle> face) {
		// TODO Auto-generated method stub
		return face.stream().map(FaceRectangleDto::new).collect(Collectors.toList());
	}
}
