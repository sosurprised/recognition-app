package br.com.fiap.RecognitionApp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.fiap.RecognitionApp.dto.PersonDto;
import br.com.fiap.RecognitionApp.model.Person;
import br.com.fiap.RecognitionApp.service.PersonService;

@RestController
@RequestMapping("/person")
public class PersonController {

	
	@Autowired
	private PersonService service;
	
	@GetMapping()
	public List<PersonDto> getAll() {
		return service.getPerson();
	}
	@GetMapping("/{id}")
	public List<PersonDto> getByid(@PathVariable(value = "id") long id){
		return service.getPersonById(id);
	}
	
	@PostMapping()
	public ResponseEntity<Person> save(@Valid @RequestBody Person person, BindingResult result, RedirectAttributes redirect) {
		if (result.hasErrors()) return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		service.save(person);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Person> updateTask(@Valid Person person, BindingResult result, RedirectAttributes redirect) {
		if (result.hasErrors()) return new ResponseEntity<>(HttpStatus.BAD_REQUEST);		
		
		service.update(person);
		return new ResponseEntity<>(HttpStatus.OK); 
	}
	
	@GetMapping("/delete/{id}")
	public ResponseEntity<Person> deleteUser(@PathVariable Long id, RedirectAttributes redirect) {
		
		service.delete(id);
		return new ResponseEntity<>(HttpStatus.OK); 
	}	
}
