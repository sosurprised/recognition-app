package br.com.fiap.RecognitionApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import br.com.fiap.RecognitionApp.dto.UserDto;
import br.com.fiap.RecognitionApp.model.User;
import br.com.fiap.RecognitionApp.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repository;
	
    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    
    public List<UserDto> getUser(){
    	
    	return UserDto.converter(repository.findAll());
    }
    
    public List<UserDto> getByIdUser(long id){
    	
    	return UserDto.converterID(repository.findById(id));
    }
    
    public ResponseEntity<User> save (User user){
    	user.setPass(encoder.encode(user.getPass()));
    	repository.save(user);
    	return ResponseEntity.ok(user);
    }
    public ResponseEntity<User> updateUser(User user){
		User userToEdit = repository.getOne(user.getId());
		
		if(userToEdit==null) new ResponseEntity<>(HttpStatus.BAD_REQUEST); 
		userToEdit = user;
		
		repository.save(userToEdit);
		return new ResponseEntity<>(HttpStatus.OK); 

    }
    public ResponseEntity<?> delete( long id){
		return repository.findById(id).map(mapper -> {
				repository.deleteById(id);
				return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
	}
	
}
