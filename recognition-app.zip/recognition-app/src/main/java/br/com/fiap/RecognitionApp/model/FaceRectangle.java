package br.com.fiap.RecognitionApp.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;

@Entity(name ="FaceRectangle" )
public class FaceRectangle {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="faceRectangler_id")
	private Long id;
	@NotBlank()
	@Column(name="top")
	private int top;
	@Column(name="left")
	private int left;
	@Column(name="width")
	private int width;
	@Column(name="height")
	private int height;
	@OneToOne(cascade=CascadeType.ALL, mappedBy="faceRectangle")
	private Measure measureId;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getTop() {
		return top;
	}
	public void setTop(int top) {
		this.top = top;
	}
	public int getLeft() {
		return left;
	}
	public void setLeft(int left) {
		this.left = left;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public Measure getMeasureId() {
		return measureId;
	}
	public void setMeasureId(Measure measureId) {
		this.measureId = measureId;
	}
	
	
	
}
