package br.com.fiap.RecognitionApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.fiap.RecognitionApp.dto.FaceRectangleDto;
import br.com.fiap.RecognitionApp.model.FaceRectangle;
import br.com.fiap.RecognitionApp.model.Measure;
import br.com.fiap.RecognitionApp.repository.FaceRectangleRepository;
import br.com.fiap.RecognitionApp.repository.MeasureRepository;

@Service
public class FaceRectangleService {

	@Autowired
	private FaceRectangleRepository repository;
	
	@Autowired
	private MeasureRepository measureRepository;
	
	public List<FaceRectangleDto> getAll(){
		return FaceRectangleDto.converter(repository.findAll());
	}
	public List<FaceRectangleDto> getById(Long id){
		return FaceRectangleDto.converterID(repository.findById(id));
	}
	   public ResponseEntity<FaceRectangle> save (FaceRectangle faces){
		   FaceRectangleDto face = new FaceRectangleDto();
			Measure me = measureRepository.getOne(face.getFaceId());
			if(me ==null) new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			repository.save(faces);
			return  new ResponseEntity<>(HttpStatus.OK);
	    }
	   
	   public ResponseEntity<FaceRectangle> update(FaceRectangle face){
			FaceRectangle faceToEdit = repository.getOne(face.getId());
			
			if(faceToEdit==null) new ResponseEntity<>(HttpStatus.BAD_REQUEST); 
			faceToEdit = face;
			
			repository.save(faceToEdit);
			return new ResponseEntity<>(HttpStatus.OK); 

	    }
	    public ResponseEntity<?> delete( long id){
			return repository.findById(id).map(mapper -> {
					repository.deleteById(id);
					return ResponseEntity.ok().build();
	        }).orElse(ResponseEntity.notFound().build());
		}
	
}
