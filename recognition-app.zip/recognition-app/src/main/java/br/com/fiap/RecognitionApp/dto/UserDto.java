package br.com.fiap.RecognitionApp.dto;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import br.com.fiap.RecognitionApp.model.User;

public class UserDto {
	
	public UserDto(User user) {
		
		this.id = user.getId();
		this.nome = user.getName();
	}
	
	private Long id;
	private String nome;
	

	public Long getId() {
		return id;
	}
	public String getNome() {
		return nome;
	}
	
	public static List<UserDto> converter(List<User> users){
		return users.stream().map(UserDto::new).collect(Collectors.toList());
	}
	
	
	public static List<UserDto> converterID(Optional<User> users) {
		// TODO Auto-generated method stub
		return users.stream().map(UserDto::new).collect(Collectors.toList());
	}
}
