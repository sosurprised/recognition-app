package br.com.fiap.RecognitionApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity(name = "measure")
public class Measure {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="measure_id")
	private Long id;
	@NotBlank()
	@Column(name="faceId")
	private String faceId;
	@NotBlank()
	@Column(name="recognitionModel")
	private String recognitionModel;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFaceId() {
		return faceId;
	}
	public void setFaceId(String faceId) {
		this.faceId = faceId;
	}
	public String getRecognitionModel() {
		return recognitionModel;
	}
	public void setRecognitionModel(String recognitionModel) {
		this.recognitionModel = recognitionModel;
	}
	
	
	
}
