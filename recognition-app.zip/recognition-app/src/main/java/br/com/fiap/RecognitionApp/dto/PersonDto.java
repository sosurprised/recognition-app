package br.com.fiap.RecognitionApp.dto;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import br.com.fiap.RecognitionApp.model.Person;

public class PersonDto {
	
	public PersonDto(Person person) {
		this.id = person.getId();
		this.name = person.getName();
		this.surname = person.getSurname();
	}
	
	private Long id;
	private String name;
	private String surname;
	
	public Long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getSurname() {
		return surname;
	}
	
	public static List<PersonDto> converter(List<Person> person){
		return person.stream().map(PersonDto::new).collect(Collectors.toList());
	}
	
	
	public static List<PersonDto> converterID(Optional<Person> person) {
		// TODO Auto-generated method stub
		return person.stream().map(PersonDto::new).collect(Collectors.toList());
	}
}
