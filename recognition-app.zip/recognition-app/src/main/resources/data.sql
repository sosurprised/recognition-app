
INSERT INTO people (name, surname, document, cpf) VALUES
('Luis', 'Amaral', '1ht87654u', '56985478589');

insert into users(name, surname, email, pass) values
('Goku', 'Saiya','testando@hotmail.com', '$2a$10$zIkZAkhBec5Vc4ig90Vto.0uw0ikcl22cKNPy4Y0qWUtQQbZX.mym' )